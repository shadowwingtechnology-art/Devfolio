# DevFolio — Developer portfolio
**Company:** Shadowing Technology

## Features
Filter projects, toggle theme, and validate a contact form.

## Files
- `index.html` — responsive UI
- `style.css` — responsive styling
- `app.js` — interactive browser behavior
- `api.php` — PHP demo endpoint
- `data.xml` — XML project metadata
- `README.md` — setup instructions

## Run
1. Open `index.html` in a browser for the front-end demo.
2. For PHP, install PHP 8+ and run `php -S localhost:8000` from this folder.
3. Visit `http://localhost:8000/api.php` to see XML.
4. POST JSON to `http://localhost:8000/api.php`, e.g.:
   `curl -X POST http://localhost:8000/api.php -H "Content-Type: application/json" -d '{"name":"Demo User","action":"test"}'`
5. PHP writes demo submissions to `submissions.json` in this folder; the folder must be writable.

## Notes
This is a portfolio demonstration. It does not process real payments or send email. CyberShield uses local heuristics only and cannot prove a URL safe. Before production deployment, implement server-side validation, authentication where needed, CSRF protection, rate limiting, secure database storage, and proper logging.
